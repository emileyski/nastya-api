export enum Roles {
  ADMIN = 'admin',
  MANAGER = 'manager',
  // CUSTOMER = 'customer',
  // // MANAGER = 'manager',
  // DRIVER = 'driver',
}
